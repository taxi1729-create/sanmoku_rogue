const MapSelectScene = {
  container:null, pendingReward:null, activeRelicId:null, // #11 マップ画面でのレリック選択・並び替え
  render(container){
    this.container=container;
    // #6 階層10：初回のみ10Gを受け取り、固定ラインナップの最終ショップへ直行する
    if(GameState.currentFloor>=10&&!GameState.finalShopDone){
      GameState.finalShopDone=true;
      GameState.gold+=10;
      App.saveGame();
      ShopScene.fixedFinalShop=true;
      App.showShop();
      return;
    }
    this._initBossEffect();
    this.renderAll();
    TutorialOverlay.show('mapSelect');
  },

  _initBossEffect(){
    const stages=GameData.buildFloorStages(GameState.currentFloor);
    const boss=stages.find(s=>s.key==='boss');
    const bossCount=boss?boss.bossEffectCount:1;
    if(!GameState.pendingBossEffect&&GameData.BOSS_EFFECT_POOL.length>0){
      GameState.bossRerollUsed=false; // #3 新しいボス出現時にリロール権をリセット
      if(bossCount<=1){
        GameState.pendingBossEffect=GlobalFunctions.randChoice(GameData.BOSS_EFFECT_POOL);
      }else{
        // 複数効果（第5階層以降）
        GameState.pendingBossEffect=GlobalFunctions.shuffle(GameData.BOSS_EFFECT_POOL).slice(0,bossCount);
      }
    }
    // #6 階層10特有ボス効果：5ターンごと（6,11,16…ターン）に次のターンがNPCになる（2つのランダムボス効果とは別枠）
    if(GameState.currentFloor>=10) GameState.floor10SpecialBoss=true;
    else GameState.floor10SpecialBoss=false;
  },

  renderAll(){
    // #4 タップのたびに画面が一番上に戻る不具合を防ぐ：スクロール位置を保持
    const scrollY=window.scrollY;
    this.container.innerHTML='';
    const el=document.createElement('div'); el.className='map-screen';
    const header=document.createElement('div'); header.className='map-header';
    header.innerHTML=`<span>所持G：${GameState.gold}</span><span>第${GameState.currentFloor}階層</span>`;
    // #2(B) デバッグ促進用：タップで20000G付与するボタン
    //const debugGoldBtn=document.createElement('button'); debugGoldBtn.className='debug-gold-btn'; debugGoldBtn.textContent='🐞+20000G';
    //debugGoldBtn.addEventListener('click',()=>{ GameState.gold+=20000; this.renderAll(); });
    //header.appendChild(debugGoldBtn);
    // #2 マップ選択画面でデッキを確認できるようにする
    const deckBtn=document.createElement('button'); deckBtn.className='debug-gold-btn'; deckBtn.textContent=`デッキ確認(${GameState.currentDeck.length})`;
    deckBtn.addEventListener('click',()=>GameMainScene.showDeckModal('deck'));
    header.appendChild(deckBtn);
    el.appendChild(header);
    // #11 マップ画面でも所持レリックを確認・並び替えできるようにする
    el.appendChild(this.renderRelicSection());
    const path=document.createElement('div'); path.className='map-path';
    const stages=GameData.buildFloorStages(GameState.currentFloor);
    stages.forEach((stage,i)=>{
      const clearedBefore=i===0||GameState.clearedStages.includes(stages[i-1].key);
      const isCleared=GameState.clearedStages.includes(stage.key);
      const locked=!clearedBefore;
      const card=document.createElement('div');
      // #4 「クリア済み・再挑戦」表記を廃止
      card.className='stage-card'+(locked?' locked':'');
      let bossInfoHtml='';
      let bossRerollBtnHtml='';
      if(stage.key==='boss'&&GameState.pendingBossEffect){
        const effects=Array.isArray(GameState.pendingBossEffect)?GameState.pendingBossEffect:[GameState.pendingBossEffect];
        bossInfoHtml=`<div class="boss-preview"><div class="boss-preview-title">ボス効果</div>${effects.map(b=>`<div class="boss-preview-item"><b>${b.name}</b>：${b.desc}</div>`).join('')}</div>`;
        // #3 ホシパッシブ1：ボス効果を一度だけリロール可能
        if(!locked&&GameState.symbolPassiveTier.Hoshi>=1&&!GameState.bossRerollUsed){
          bossRerollBtnHtml=`<button class="boss-reroll-btn">☆ボス効果リロール（残り1回）</button>`;
        }
      }
      // #7 スキップ報酬内容をステージ上に表示
      let skipBonusHtml='';
      let skipBonus=null;
      if(stage.skippable&&!isCleared&&!locked){
        skipBonus=this.getSkipBonus(stage);
        const base=GameData.SKIP_REWARD_BASE[stage.key]||1; const flat=GameData.REWARD_FLAT_BONUS;
        skipBonusHtml=`<div class="skip-bonus-tag">スキップ報酬：G+${base+flat}${skipBonus?`　＋　${skipBonus.label}`:'（追加報酬なし）'}</div>`;
      }
      const actionsHtml=isCleared
        ? `<div class="stage-actions"><div class="stage-done-tag">クリア済み</div></div>`
        : `<div class="stage-actions"><button class="challenge-btn" ${locked?'disabled':''}>挑戦する</button>${stage.skippable?`<button class="skip-btn" ${locked?'disabled':''}>スキップ</button>`:''}</div>`;
      card.innerHTML=`<div class="stage-tag">${stage.tag}</div><div class="stage-name">${stage.name}</div><div class="stage-goal">目標：${GlobalFunctions.formatScore(stage.targetScore)}点</div>${bossInfoHtml}${bossRerollBtnHtml}${skipBonusHtml}${actionsHtml}`;
      path.appendChild(card);
      const challengeBtn=card.querySelector('.challenge-btn');
      if(challengeBtn) challengeBtn.addEventListener('click',()=>{ if(locked) return; App.showGameMain(stage); });
      // #3 ホシパッシブ1：ボス効果リロール
      const bossRerollBtn=card.querySelector('.boss-reroll-btn');
      if(bossRerollBtn) bossRerollBtn.addEventListener('click',()=>{
        const bossCount=Array.isArray(GameState.pendingBossEffect)?GameState.pendingBossEffect.length:1;
        GameState.pendingBossEffect = bossCount<=1
          ? GlobalFunctions.randChoice(GameData.BOSS_EFFECT_POOL)
          : GlobalFunctions.shuffle(GameData.BOSS_EFFECT_POOL).slice(0,bossCount);
        GameState.bossRerollUsed=true;
        this.renderAll();
      });
      const skipBtn=card.querySelector('.skip-btn');
      if(skipBtn) skipBtn.addEventListener('click',()=>{
        if(locked||isCleared) return;
        const base=GameData.SKIP_REWARD_BASE[stage.key]||1;
        const flat=GameData.REWARD_FLAT_BONUS; const total=base+flat;
        GameState.gold+=total;
        const bonus=skipBonus||this.getSkipBonus(stage);
        const bonusMsg=this.applySkipBonusEffect(bonus);
        GameState.lastReward={type:'skip',stageName:stage.name,gold:total,breakdown:{base,bonus:0,flat,total},extra:bonusMsg};
        if(!GameState.clearedStages.includes(stage.key)) GameState.clearedStages.push(stage.key);
        // #8 スキップ時セーブ
        App.saveGame();
        this.pendingReward={stageName:stage.name,breakdown:{base,bonus:0,flat,total},gold:total,extra:bonusMsg};
        this.renderAll();
      });
    });
    el.appendChild(path);

    // 全クリア→次の階層へ
    if(GameState.clearedStages.includes('boss')){
      const nextFloor=GameState.currentFloor+1;
      const done=document.createElement('div'); done.style.marginTop='18px';
      if(GameState.currentFloor>=10){
        // #2 階層10クリア時はエンディング（ゲームクリア画面＋スタッフロール）へ
        done.innerHTML=`<div style="color:var(--gold);font-weight:900;margin-bottom:10px;">🎉 全10階層クリア！おめでとうございます！</div><button id="btn-show-ending">エンディングへ</button>`;
      }else if(GameState.currentFloor===5){
        done.innerHTML=`<div style="color:var(--square);font-weight:900;margin-bottom:10px;">第5階層クリア！ゲームクリア！やり込み要素として第6階層以降も挑戦できます。</div><button id="btn-next-floor">第${nextFloor}階層へ</button><button id="btn-back-title" style="margin-left:8px;">タイトルに戻る</button>`;
      }else{
        done.innerHTML=`<div style="color:var(--square);font-weight:900;margin-bottom:10px;">第${GameState.currentFloor}階層クリア！</div><button id="btn-next-floor">第${nextFloor}階層へ</button>`;
      }
      el.appendChild(done);
      setTimeout(()=>{
        const b=el.querySelector('#btn-next-floor');
        if(b) b.addEventListener('click',()=>{
          GameState.currentFloor=nextFloor;
          GameState.clearedStages=[];
          GameState.pendingBossEffect=null;
          // 最高クリア記録更新
          if(GameState.currentFloor-1>GameState.maxClearedFloor){ GameState.maxClearedFloor=GameState.currentFloor-1; GameState.maxClearedStage='ボス'; }
          App.saveGame();
          // #4 第10階層への移動時は、経由するレンダリングを1回挟まず直接最終ショップへ向かう
          if(GameState.currentFloor>=10 && !GameState.finalShopDone){
            GameState.finalShopDone=true;
            GameState.gold+=10;
            App.saveGame();
            ShopScene.fixedFinalShop=true;
            App.showShop();
          }else{
            App.showMapSelect();
          }
        });
        const t=el.querySelector('#btn-back-title');
        if(t) t.addEventListener('click',()=>App.showTitle());
        // #2 階層10クリア時：エンディング（ゲームクリア画面＋スタッフロール）へ
        const eb=el.querySelector('#btn-show-ending');
        if(eb) eb.addEventListener('click',()=>{
          App.saveGame();
          App.showEnding();
        });
      });
    }
    this.container.appendChild(el);
    if(this.pendingReward) this.container.appendChild(this.renderRewardPopup());
    window.scrollTo(0,scrollY);
  },

  // #11 レリック表示・並び替え（他画面と同じくindexで個体を識別。処理順は常に配列の左から右）
  renderRelicSection(){
    const area=document.createElement('div'); area.className='shop-relic-confirm';
    area.innerHTML=`<div class="shop-section-title">所持レリック（${GameState.usedRelicSlots()}/${GameState.effectiveMaxRelics()}）</div>`;
    const row=document.createElement('div'); row.className='relic-display-row';
    if(GameState.relics.length===0){
      const empty=document.createElement('div'); empty.className='relic-empty'; empty.textContent='なし'; row.appendChild(empty);
    }else{
      GameState.relics.forEach((relic,i)=>{
        const rc=document.createElement('div');
        rc.className='relic-card'+(this.activeRelicId===i?' active':'');
        rc.innerHTML=`<div class="relic-name">${relic.name}</div>${relic.relicEnhance?`<div class="relic-enhance-tag">${GameData.RELIC_ENHANCE_POOL.find(r=>r.id===relic.relicEnhance)?.name||''}</div>`:''}`;
        rc.addEventListener('click',()=>{ this.activeRelicId=(this.activeRelicId===i)?null:i; this.renderAll(); });
        row.appendChild(rc);
      });
    }
    area.appendChild(row);
    if(this.activeRelicId!=null){
      const idx=this.activeRelicId;
      const relic=GameState.relics[idx];
      if(relic){
        const ren=GameData.RELIC_ENHANCE_POOL.find(r=>r.id===relic.relicEnhance);
        const infoDiv=document.createElement('div'); infoDiv.className='relic-info-panel'; infoDiv.style.marginTop='8px';
        infoDiv.innerHTML=`<div class="info-title">${relic.name}</div><div class="info-desc">${relic.desc}</div>${ren?`<div class="info-desc relic-enhance-desc">【${ren.name}】${ren.desc}</div>`:''}<div class="relic-reorder-row"><button class="relic-move-btn" ${idx<=0?'disabled':''}>◀ 左へ</button><button class="relic-move-btn" ${idx>=GameState.relics.length-1?'disabled':''}>右へ ▶</button></div>`;
        const moveBtns=infoDiv.querySelectorAll('.relic-move-btn');
        moveBtns[0].addEventListener('click',()=>{ if(GameState.moveRelic(idx,-1)){ this.activeRelicId=idx-1; this.renderAll(); } });
        moveBtns[1].addEventListener('click',()=>{ if(GameState.moveRelic(idx,1)){ this.activeRelicId=idx+1; this.renderAll(); } });
        area.appendChild(infoDiv);
      }
    }
    return area;
  },

  renderRewardPopup(){
    const r=this.pendingReward;
    const overlay=document.createElement('div'); overlay.className='pack-modal-overlay';
    const box=document.createElement('div'); box.className='gold-reveal-popup';
    box.innerHTML=`<div class="gr-label">${r.stageName}をスキップ</div><div class="gr-total">+${r.gold}G</div><div class="gr-breakdown">基礎G+${r.breakdown.base} ＋ 基本G+${r.breakdown.flat}${r.extra?`<br>追加報酬：${r.extra}`:''}</div><button id="btn-goto-shop" style="margin-top:16px;">ショップへ</button>`;
    overlay.appendChild(box);
    setTimeout(()=>{ box.querySelector('#btn-goto-shop').addEventListener('click',()=>{ this.pendingReward=null; App.showShop(); }); });
    return overlay;
  },

  // #7 スキップ報酬の追加ボーナスを階層＋ステージごとに1回だけ抽選してキャッシュする
  getSkipBonus(stage){
    if(!this._skipBonusCache) this._skipBonusCache={};
    const key=GameState.currentFloor+'_'+stage.key;
    if(this._skipBonusCache[key]===undefined){
      const type=GameData.pickSkipBonusType();
      let label=null;
      if(type==='relic'){ label='レリック🔴：ランダムレリック1つを獲得'; }
      else if(type==='normal_upgrade'){ label='通常アップグレード：ショップでカードと効果を選択'; }
      else if(type==='special_upgrade'){ label='特別アップグレード：ショップでカードと効果を選択'; }
      else if(type==='normal_explosive_upgrade'){ label='💥爆発通常アップグレード：ショップで最大3つ選択'; }
      else if(type==='dream_card'){ label='ドリームカードパック'; }
      this._skipBonusCache[key]=type?{type,label}:null;
    }
    return this._skipBonusCache[key];
  },

  // #8 スキップ報酬の追加ボーナスを実際に付与する（通常/特別アップグレードは通常通りショップでカード・効果を選択させる）
  applySkipBonusEffect(bonus){
    if(!bonus||!bonus.type) return '';
    if(bonus.type==='relic'){
      const relic=ShopScene.pickRelic();
      if(ShopScene.canAcquireRelic(relic)){
        GameState.relics.push(relic);
        ShopScene.applyRelicGrantEffect(relic);
        GlobalFunctions.recordRelic(relic.id);
        return `レリック「${relic.name}」を獲得`;
      }
      GameState.gold+=5; return 'レリック枠が満杯のため代わりにG+5';
    }
    if(bonus.type==='normal_upgrade'||bonus.type==='special_upgrade'){
      if(GameState.currentDeck.length===0) return '';
      const slotType = bonus.type==='special_upgrade' ? 'special' : 'normal';
      const pickCount = Math.min(8, GameState.currentDeck.length);
      const cardIndexes = GlobalFunctions.shuffle(GameState.currentDeck.map((_,idx)=>idx)).slice(0, pickCount);
      let effectPool;
      if(slotType==='special'){
        const unused = GameData.SPECIAL_SELECT_POOL.filter(e=>!GameState.usedSpecialEffectIds.includes(e.id));
        // #9 特別アップグレードを全て取得済みの場合、既に取得済みの効果を再度出さず「確定性質変化付与」にする（ショップの仕様と統一）
        if(unused.length===0){
          const forcedEffect = { id:'grant_trait', name:'性質変化付与（確定）', desc:'カードを1枚選択しランダムな性質変化を付与', targetMin:1, targetMax:1 };
          effectPool = [forcedEffect];
        }else{
          effectPool = GlobalFunctions.shuffle(unused).slice(0, Math.min(2, unused.length));
        }
      }else{
        const pool = GameData.NORMAL_SELECT_POOL.filter(e=>{ if(e.rarity) return Math.random()<e.rarity; return true; });
        const finalPool = pool.length>0 ? pool : GameData.NORMAL_SELECT_POOL.filter(e=>!e.rarity);
        effectPool = GlobalFunctions.shuffle(finalPool).slice(0, Math.min(3, finalPool.length));
      }
      // #8 通常のショップ購入と同じ「効果→カード」選択モーダルをショップ画面側で開かせる
      ShopScene.pickingPack = { slotType, slotRef:null, effectPool, chosenEffect:null, cardIndexes, selectedTargets:new Set() };
      return 'ショップでカードと効果を選択してください';
    }
    if(bonus.type==='dream_card'){
      // #9 ドリームパックも通常通りショップでカードを選択できるようにする
      const candidates=[ShopScene.genDreamCard(), ShopScene.genDreamCard()];
      ShopScene.pickingCardPack = { candidates, pickCount:1, isDream:true };
      return 'ショップでドリームカードを選択してください';
    }
    // #7 爆発通常アップグレードをスキップ報酬に組み込む
    if(bonus.type==='normal_explosive_upgrade'){
      if(GameState.currentDeck.length===0) return '';
      ShopScene.pickingPack = ShopScene.buildExplosiveUpgradePack(null);
      return 'ショップで💥爆発通常アップグレードを選択してください（5つから最大3つまで選択可）';
    }
    return '';
  },
};
